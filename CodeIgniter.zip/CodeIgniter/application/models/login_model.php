<?php

class Login_Model extends CI_Model {

   public function __construct()
    {
        $this->load->database();
    }
    
    public function get_user_login($username, $password)
    {
		
        $query = $this->db->get_where('tbl_admin',
		array('email' => $username, 
		'password' => md5($password)));    
		
        //return $query->num_rows();
        return $query->row_array();
    }

    public function logout() {
        $this->session->sess_destroy();
    }

    public function loggedin() {
        return (bool) $this->session->userdata('loggedin');
    }

   
}
