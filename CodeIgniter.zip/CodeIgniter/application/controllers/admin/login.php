<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Login extends CI_Controller {
	
	
    public function __construct() {
        parent::__construct();
		   parent::__construct();
       
        $this->load->helper('url_helper');
        $this->load->library('session');
        $this->load->library('pagination');
        $this->load->helper(array('form', 'url'));
        $this->load->library(array('session', 'form_validation'));
        $this->load->model('login_model');
    }
	
    public function index() {
		
		
			$this->load->view('admin/login');
		}
        public function login() {
		
		$username 		= $this->input->post('username');
        $password 		= $this->input->post('password');
		
		$this->form_validation->set_rules('username', 'username', 'trim|required');
		$this->form_validation->set_rules('password', 'password', 'trim|required');
		
        if ($this->form_validation->run() == TRUE) {
		
            // We can login and redirect
			
          if ($user = $this->login_model->get_user_login($username, $password))
				{
				   // We can login and redirect
					$data = array(
						
						'id' 			=> 	$user['id'],
						'username' 		=> 	$user['email'],
						'status' 		=> 	1,
						'logged_in'		=>	TRUE,
						'url' 			=> 'admin/dashboard',
					);
						 
					$this->session->set_userdata($data);
					redirect($this->session->userdata('url'));
				} 
				else 
				{
					//echo "hi";die;
					$this->session->set_flashdata('flashError', 'Username / Password combination does not match');
					redirect('admin/login');
				}
        }

		else{
			
			$data['subview'] = $this->load->view('admin/login', NULL, TRUE);
			$this->load->view('admin/login', $data);
		}
        
    }
		
        
    
		
    public function logout() {
		
        $this->session->unset_userdata('id');
		$this->session->unset_userdata('username');
		$this->session->unset_userdata('status');
		$this->session->unset_userdata('logged_in');
		$this->session->unset_userdata('url');
		$this->session->sess_destroy();
		redirect('admin/login');
       
    }

}
